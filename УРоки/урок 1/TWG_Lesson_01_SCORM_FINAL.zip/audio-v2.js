(function(){
  "use strict";
  var TRANSCRIPTS={
    "slide01":["Посмотрите на схему целиком. Вода проходит несколько последовательных этапов — от источника до потребителя. Сначала источник даёт воду системе. Затем насос создаёт необходимый поток и давление. После этого дисковый фильтр TWG DF задерживает механические примеси и защищает оборудование. Основная водоподготовка решает задачи, связанные с составом воды. BB20 PRO выполняет финишную механическую доочистку. И только после этого подготовленная вода поступает к потребителю. Главное — воспринимать эту цепочку как одну систему, а не как набор отдельных устройств."],
    "slide02":["Здесь важно понять две вещи. Первая: для нормальной работы системы нужны одновременно и расход, и давление. Наличие хорошего давления ещё не означает, что воды хватит при реальном водоразборе. Вторая: каждый узел создаёт гидравлическое сопротивление. Трубопровод, арматура, фильтр и колонна влияют на общий поток. Поэтому частая ошибка — выбрать мощный насос и считать, что дальше всё заработает автоматически. Правильнее оценивать систему целиком и смотреть, какой расход и давление реально доходят до оборудования."],
    "slide03":["Подведём итог. Система водоснабжения начинается с источника, затем насос создаёт поток и давление, TWG DF выполняет предварительную механическую очистку, основная водоподготовка удаляет основные загрязнения, а BB20 PRO завершает механическую доочистку. Каждый узел выполняет свою функцию и одновременно влияет на всю систему. Пока мы не разбираем загрузки, аэрацию, управляющие клапаны и подбор колонн. Главная мысль урока простая: правильная водоподготовка начинается с понимания всего пути воды — от источника до потребителя."]
  };
  function fmt(sec){if(!Number.isFinite(sec)||sec<0)return"0:00";var m=Math.floor(sec/60),s=Math.floor(sec%60);return m+":"+(s<10?"0":"")+s;}
  function init(card){
    var audio=card.querySelector("audio"),play=card.querySelector(".audio-play"),icon=card.querySelector(".audio-play-icon"),seek=card.querySelector(".audio-seek"),cur=card.querySelector(".audio-current"),dur=card.querySelector(".audio-duration"),back=card.querySelector(".audio-back"),forward=card.querySelector(".audio-forward"),speed=card.querySelector(".audio-speed"),volume=card.querySelector(".audio-volume"),heading=card.querySelector(".audio-heading");
    var audioPath=audio?audio.getAttribute("src")||"":"";var audioKey=(audioPath.match(/(slide\d{2})\.mp3(?:[?#].*)?$/i)||[])[1];var transcript=audioKey?TRANSCRIPTS[audioKey.toLowerCase()]:null;
    if(heading&&transcript&&transcript.length){var readButton=document.createElement("button");readButton.className="read-toggle";readButton.type="button";readButton.textContent="Прочитать";readButton.setAttribute("aria-haspopup","dialog");heading.appendChild(readButton);var overlay=document.createElement("div");overlay.className="read-overlay";overlay.hidden=true;overlay.innerHTML='<section class="read-dialog" role="dialog" aria-modal="true" aria-label="Текст аудиоролика"><header><strong>Текст аудиоролика</strong><button class="read-close" type="button" aria-label="Закрыть">×</button></header><div class="read-content"></div></section>';document.body.appendChild(overlay);var content=overlay.querySelector(".read-content");transcript.forEach(function(value){var p=document.createElement("p");p.textContent=value;content.appendChild(p);});var closeButton=overlay.querySelector(".read-close");function openText(){overlay.hidden=false;closeButton.focus();}function closeText(){overlay.hidden=true;readButton.focus();}readButton.addEventListener("click",openText);closeButton.addEventListener("click",closeText);overlay.addEventListener("click",function(e){if(e.target===overlay)closeText();});document.addEventListener("keydown",function(e){if(e.key==="Escape"&&!overlay.hidden)closeText();});}
    if(!audio)return;
    card.classList.remove("is-placeholder");
    function update(){var value=audio.duration?(audio.currentTime/audio.duration)*100:0;seek.value=value;seek.style.setProperty("--audio-progress",value+"%");cur.textContent=fmt(audio.currentTime);dur.textContent=fmt(audio.duration);}
    audio.addEventListener("loadedmetadata",update);
    audio.addEventListener("durationchange",update);
    audio.addEventListener("timeupdate",update);
    audio.addEventListener("play",function(){icon.textContent="❚❚";play.setAttribute("aria-label","Пауза");});
    audio.addEventListener("pause",function(){icon.textContent="▶";play.setAttribute("aria-label","Воспроизвести");});
    audio.addEventListener("ended",function(){icon.textContent="▶";play.setAttribute("aria-label","Воспроизвести");update();});
    audio.addEventListener("error",function(){if(heading){var st=document.createElement("span");st.className="audio-status";st.textContent="Ошибка загрузки аудио";heading.appendChild(st);}console.error("Не удалось загрузить аудио:",audio.src,audio.error);});
    play.addEventListener("click",function(){if(audio.paused){var promise=audio.play();if(promise&&promise.catch){promise.catch(function(err){console.error("Ошибка воспроизведения:",err);});}}else{audio.pause();}});
    seek.addEventListener("input",function(){if(audio.duration){audio.currentTime=(Number(seek.value)/100)*audio.duration;update();}});
    back.addEventListener("click",function(){audio.currentTime=Math.max(0,audio.currentTime-10);update();});
    forward.addEventListener("click",function(){audio.currentTime=Math.min(audio.duration||0,audio.currentTime+10);update();});
    speed.addEventListener("click",function(){var rates=[1,1.25,1.5,2],idx=rates.indexOf(audio.playbackRate);audio.playbackRate=rates[(idx+1)%rates.length];speed.textContent=audio.playbackRate+"×";});
    volume.addEventListener("click",function(){audio.muted=!audio.muted;});
    audio.load();
    update();
  }
  document.addEventListener("DOMContentLoaded",function(){document.querySelectorAll(".audio-card").forEach(init);});
})();
