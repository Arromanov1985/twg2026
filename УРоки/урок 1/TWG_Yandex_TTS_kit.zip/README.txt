TWG Yandex TTS Kit

1) Распакуйте архив в любую папку, например:
   C:\TWG_TTS

2) Откройте эту папку в VS Code.

3) В терминале PowerShell выполните:
   py -m venv .venv
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   Copy-Item .env.example .env

4) Откройте файл .env и вставьте:
   YANDEX_API_KEY=ВАШ_КЛЮЧ
   YANDEX_FOLDER_ID=ВАШ_FOLDER_ID
   YANDEX_VOICE=ermil
   YANDEX_EMOTION=good
   YANDEX_SPEED=1.0

5) Тест первого слайда:
   python .\yandex_tts.py --slide 1 --overwrite

6) Генерация всех файлов:
   python .\yandex_tts.py --overwrite

Готовые MP3 появятся в папке:
   audio\slide01.mp3
   audio\slide02.mp3
   audio\slide03.mp3

Тексты лежат в:
   text\slide01.txt
   text\slide02.txt
   text\slide03.txt
